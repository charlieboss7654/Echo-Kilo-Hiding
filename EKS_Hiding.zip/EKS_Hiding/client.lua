-- ?? Manifest validation
CreateThread(function()
    local resourceName = GetCurrentResourceName()
    local fxmanifest = LoadResourceFile(resourceName, "fxmanifest.lua")

    if not fxmanifest or not string.find(fxmanifest, "R.Robertson %- Echo Kilo Studios") then
        print("^1[Echo Kilo Hiding] Missing required author string in fxmanifest. Stopping resource.^0")
        StopResource(resourceName)
    end
end)

local isHiding       = false
local currentEntity  = nil
local hidingType     = nil 
local exitKey        = 73 
local targetsEnabled = true

local ANIM_DICT_CAR  = "anim@heists@ornate_bank@hostages@hit"
local ANIM_NAME_CAR  = "hit_react_die_loop_ped_a"

local dumpsterModels = {
    `prop_dumpster_01a`,
    `prop_dumpster_02a`,
    `prop_dumpster_02b`,
    `prop_dumpster_02c`,
    `prop_dumpster_3a`,
    `prop_dumpster_3b`,
    `prop_dumpster_4a`,
    `prop_dumpster_4b`,
    `prop_cs_dumpster_01a`,
    `prop_cs_dumpster_01b`
}

local function notify(desc, ntype)
    lib.notify({
        title = "Hide System",
        description = desc,
        type = ntype or "inform"
    })
end

local function loadAnimDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
end

local function safeSetCoords(ped, x, y, z, tryGround)
    if tryGround then
        local ok, gz = GetGroundZFor_3dCoord(x, y, z + 1.0, false)
        if ok then z = gz end
    end
    SetEntityCoords(ped, x, y, z, false, false, false, true)
end

local function hideUnderVehicle(veh)
    if isHiding then return end
    currentEntity = veh
    hidingType    = "car"

    local minDim = GetModelDimensions(GetEntityModel(veh))
    local under = GetOffsetFromEntityInWorldCoords(veh, 0.0, 0.0, minDim + 0.04)

    safeSetCoords(PlayerPedId(), under.x, under.y, under.z, true)
    loadAnimDict(ANIM_DICT_CAR)
    TaskPlayAnim(PlayerPedId(), ANIM_DICT_CAR, ANIM_NAME_CAR, 8.0, -8.0, -1, 1, 0.0, false, false, false)

    isHiding = true
    notify("You are now hiding under the vehicle. Press X to exit.", "success")
end

local function hideInDumpster(obj)
    if isHiding then return end
    currentEntity = obj
    hidingType    = "dumpster"

    local ped = PlayerPedId()
    local minDim, maxDim = GetModelDimensions(GetEntityModel(obj))
    local offsetZ = minDim.z + ((maxDim.z - minDim.z) / 2)

    AttachEntityToEntity(ped, obj, -1, 0.0, 0.0, offsetZ, 0.0, 0.0, 0.0, false, false, false, false, 2, true)

    FreezeEntityPosition(ped, true)
    SetEntityVisible(ped, false, false)

    isHiding = true
    notify("You climbed into the dumpster. Press X to climb out.", "success")

    if NetworkGetEntityIsNetworked(obj) then
        TriggerServerEvent("eks:hidingInDumpster", ObjToNet(obj))
    end
end

local function exitHiding()
    if not isHiding then return end
    local ped = PlayerPedId()

    if hidingType == "car" and currentEntity and DoesEntityExist(currentEntity) then
        local minDim, _ = GetModelDimensions(GetEntityModel(currentEntity))
        local out = GetOffsetFromEntityInWorldCoords(currentEntity, 0.0, minDim.y - 0.5, 0.0)
        safeSetCoords(ped, out.x, out.y, out.z, true)

    elseif hidingType == "dumpster" and currentEntity and DoesEntityExist(currentEntity) then
        DetachEntity(ped, true, true)
        FreezeEntityPosition(ped, false)
        SetEntityVisible(ped, true, false)

        local minDim, _ = GetModelDimensions(GetEntityModel(currentEntity))
        local back = GetOffsetFromEntityInWorldCoords(currentEntity, 0.0, minDim.y - 0.5, 0.0)
        safeSetCoords(ped, back.x, back.y, back.z, true)

        if NetworkGetEntityIsNetworked(currentEntity) then
            TriggerServerEvent("eks:leftDumpster", ObjToNet(currentEntity))
        end
    end

    ClearPedTasks(ped)
    isHiding, hidingType, currentEntity = false, nil, nil
    notify("You exited your hiding spot.", "inform")
end

RegisterNetEvent("eks:forceOutDumpster", function()
    if isHiding and hidingType == "dumpster" then
        exitHiding()
    end
end)

RegisterNetEvent("eks:checkResult", function(found)
    if found then
        notify("You found someone hiding in the dumpster!", "success")
    else
        notify("You checked the dumpster, but it was empty.", "inform")
    end
end)

local function registerTargets()
    exports.ox_target:addGlobalVehicle({
        {
            name = 'eks_hideunder',
            icon = 'fa-solid fa-person-arrow-down-to-line',
            label = 'Hide Under Vehicle',
            distance = 2.0,
            onSelect = function(data) hideUnderVehicle(data.entity) end
        }
    })

    exports.ox_target:addModel(dumpsterModels, {
        {
            name = 'eks_hideindumpster',
            icon = 'fa-solid fa-dumpster',
            label = 'Hide In Dumpster',
            distance = 2.0,
            onSelect = function(data) hideInDumpster(data.entity) end
        },
        {
            name = 'eks_checkdumpster',
            icon = 'fa-solid fa-search',
            label = 'Check Dumpster',
            distance = 2.0,
            onSelect = function(data)
                if NetworkGetEntityIsNetworked(data.entity) then
                    TriggerServerEvent("eks:checkDumpster", ObjToNet(data.entity))
                else
                    notify("You checked the dumpster, but it was empty.", "inform")
                end
            end
        }
    })
end

local function toggleTargets()
    if targetsEnabled then
        exports.ox_target:removeGlobalVehicle('eks_hideunder')
        exports.ox_target:removeModel(dumpsterModels, 'eks_hideindumpster')
        exports.ox_target:removeModel(dumpsterModels, 'eks_checkdumpster')
        targetsEnabled = false
        notify("Hide options disabled.", "inform")
    else
        registerTargets()
        targetsEnabled = true
        notify("Hide options enabled.", "success")
    end
end

RegisterCommand('+toggleHideTargets', function() toggleTargets() end, false)
RegisterCommand('-toggleHideTargets', function() end, false)
RegisterKeyMapping('+toggleHideTargets', 'Toggle hide options', 'keyboard', 'G')

CreateThread(function()
    while true do
        Wait(0)
        if isHiding and IsControlJustPressed(0, exitKey) then
            exitHiding()
        end
    end
end)

CreateThread(function()
    registerTargets()
end)
