CreateThread(function()
    local resourceName = GetCurrentResourceName()
    local fxmanifest = LoadResourceFile(resourceName, "fxmanifest.lua")

    if not fxmanifest or not string.find(fxmanifest, "R.Robertson %- Echo Kilo Studios") then
        print("^1[Echo Kilo Hiding] Missing required author string in fxmanifest. Stopping resource.^0")
        StopResource(resourceName)
    end
end)

local dumpsterOccupants = {} 

RegisterNetEvent("eks:hidingInDumpster", function(netId)
    dumpsterOccupants[netId] = source
end)

RegisterNetEvent("eks:leftDumpster", function(netId)
    if dumpsterOccupants[netId] == source then
        dumpsterOccupants[netId] = nil
    end
end)

RegisterNetEvent("eks:checkDumpster", function(netId)
    local src = source
    local occupant = dumpsterOccupants[netId]

    if occupant then
        TriggerClientEvent("eks:forceOutDumpster", occupant)
        dumpsterOccupants[netId] = nil

        TriggerClientEvent("eks:checkResult", src, true)
    else
        TriggerClientEvent("eks:checkResult", src, false)
    end
end)
