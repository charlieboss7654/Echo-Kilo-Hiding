fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Echo Kilo Hiding!'
version '1.0'

shared_script '@ox_lib/init.lua'

client_scripts { 
    'client/client.lua'
}

server_scripts { 
    'server/server.lua'
}

lua54 'yes'
